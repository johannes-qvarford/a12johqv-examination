﻿namespace a12johqv.Examination.Chess
{
    /// Types of chess pieces.
    public enum PieceType
    {
        Pawn,
        Rook,
        Knight,
        Bishop,
        Queen,
        King
    }
}