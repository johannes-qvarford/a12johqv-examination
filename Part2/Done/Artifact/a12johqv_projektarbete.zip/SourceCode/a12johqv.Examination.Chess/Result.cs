﻿namespace a12johqv.Examination.Chess
{
    /// The result of an ongoing or finished match.
    public enum Result
    {
        Undecided,
        WhiteVictory,
        BlackVictory,
        Draw
    }
}