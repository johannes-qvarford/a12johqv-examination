﻿namespace a12johqv.Examination.Chess
{
    /// Colors of a chess piece or player.
    public enum Color
    {
        White,
        Black
    }
}