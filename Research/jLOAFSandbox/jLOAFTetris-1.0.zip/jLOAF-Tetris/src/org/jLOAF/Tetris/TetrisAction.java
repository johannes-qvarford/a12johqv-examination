package org.jLOAF.Tetris;

import org.jLOAF.action.ComplexAction;

public class TetrisAction extends ComplexAction {

	private static final long serialVersionUID = 1L;

	public TetrisAction(){
		super("Tetris Action");
	}
}
