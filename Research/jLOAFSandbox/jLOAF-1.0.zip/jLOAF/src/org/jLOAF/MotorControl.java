package org.jLOAF;

import org.jLOAF.action.Action;


public abstract class MotorControl {

	public abstract String control(Action a);
	
}
