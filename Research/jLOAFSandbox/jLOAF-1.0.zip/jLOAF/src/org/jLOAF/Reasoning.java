package org.jLOAF;

import org.jLOAF.action.Action;
import org.jLOAF.inputs.Input;

public interface Reasoning {

	public Action selectAction(Input i);
}
