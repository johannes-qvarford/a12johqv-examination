package org.jLOAF;

public interface Perception {

}
