﻿namespace ilf.pgn

open System.Reflection
open System.Runtime.CompilerServices
open System.Runtime.InteropServices

[<assembly: ComVisible(false)>]

[<assembly: AssemblyTitle("ilf.pgn.PgnParser.dll")>]
[<assembly: AssemblyDescription("ilf.pgn.PgnParser.dll")>]

[<assembly: AssemblyProduct("pgn.net")>]
[<assembly: AssemblyCopyright("Copyright \169 Igor Lankin 2013")>]
[<assembly: AssemblyVersion("1.0.0.0")>]
[<assembly: AssemblyFileVersion("1.0.0.0")>]
[<assembly: InternalsVisibleTo("pgn.NET")>]
[<assembly: InternalsVisibleTo("pgn.Parse.Test")>]
[<assembly: InternalsVisibleTo("pgn.NET.Test")>]
[<assembly: InternalsVisibleTo("pgn.NET.Test.Special")>]
do ()