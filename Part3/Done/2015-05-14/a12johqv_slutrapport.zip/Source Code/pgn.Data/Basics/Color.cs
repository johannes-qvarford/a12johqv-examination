﻿namespace ilf.pgn.Data
{
    /// <summary>
    /// Piece color.
    /// </summary>
    public enum Color
    {
        /// <summary> White </summary>
        White,
        /// <summary> Black </summary>
        Black
    }
}