﻿namespace a12johqv.Examination.Chess
{
    /// A side of the chess board seen from white's perspective.
    public enum Side
    {
        Left,
        Right
    }
}