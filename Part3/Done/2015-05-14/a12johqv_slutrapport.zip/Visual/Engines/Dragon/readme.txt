Name: 		Dragon
Programmer: 	Bruno LUCAS
Country: 	France
Version: 	4.6
ELO: 		2.400
Playing styl: 	Positional


Dragon 4.x:
"Is based on bitboard. It has the evaluation of Dragon 3.X. The search
is updated. I remove bad extensions greedy in nodes and time. The main
difference beetween Dragon 4.0 and Dragon 3.x is that the writing of
Dragon 4.0 shows that Dragon 3 has many incoherences in search extension,
sort of moves and bad test in evaluation. The cleaning of the source are
very benefit. The change I made in Dragon 4 are more rigourous that the
change I made in Dragon 3.

Protocol: UCI (setup version)
Protocol: WB II, available on WBEC Ridderkerk:
http://wbec-ridderkerk.nl/

Opening book -1: Small book in setup
Opening book -2: Bigger book available on WBEC Ridderkerk:
http://wbec-ridderkerk.nl/

Dragon supported: Nalimov tablebases (endgame databases):
http://www.playwitharena.com/download/4-pieces-tbs.zip
(three and four pieces tablebases = 31.05Mb)

Offical results:
----------------

1996, 4th France-ch Clichy 5/9 points, 			ranking 06 of 10 
1997, 5th France-ch Clichy 4/9 points, 			ranking 09 of 14 
1997, 15th WMCCC Paris 3/11 points, 			ranking 33 of 34 
1998, 6th France-ch Clichy 7/11 points, 		ranking 09 of 16 
1999, 1st French programmers Massy 4/7 points, 		ranking 05 of 12 
2000, 8th France-ch Massy 6/9 points, 			ranking 03 of 10 
2000, 2nd French programmers Massy 2/6 points, 		ranking 07 of 10 
2001, 3rd French programmers Massy 3/6 points, 		ranking 07 of 12 
2002, 4th French programmers Massy 3/6 points, 		ranking 07 of 12 
2002, 9th France-ch Massy 8/11 points, 			ranking 04 of 12 
2003, 5th French programmers Massy 3.5/6 points, 	ranking 06 of 18 
2003, 10th France-ch Massy 5/7 points, 			ranking 02 of 14 


Schweich-Issel, Germany
19.12.2004, Frank Quisinsky

