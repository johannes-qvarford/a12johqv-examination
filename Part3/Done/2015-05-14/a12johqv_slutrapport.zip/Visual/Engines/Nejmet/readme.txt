Name: 		Nejmet
Programmer: 	Jean-Christophe GABILLARD
Country: 	France
Version: 	3.07
ELO: 		2.450
Playing styl: 	Positional, Endgame

"Nejmet is an amateur program which was started in 1997. This program has
a level  similar to a International Great Master of Chess. Nejmet use the
ABDADA algorithm on multiprocessor computers. It�s able to think on opponent�s
time. His opening book has been created with lots of IGM�s games and it�s able
to learn to avoid the unsuccessful lines into openings. Nejmet is an endgame
expert when it use the endgame database to Nalimov format."


Protocol: UCI (setup version)
Protocol: WB II, available on Nejmet webpage:
http://membres.lycos.fr/nejmet/

Opening book: Main book included in setup.

Nejmet supported: Nalimov tablebases (endgame databases):
http://www.playwitharena.com/download/4-pieces-tbs.zip
(three and four pieces tablebases = 31.05Mb)

Offical results:
----------------

1998, 6th France-ch Clichy 5/11 points, 		ranking 11 of 16 
1999, 7th France-ch Clichy 4.5/7 points, 		ranking 05 of 12 
2000, 8th France-ch Massy 4/9 points, 			ranking 07 of 10 


Schweich-Issel, Germany
19.12.2004, Frank Quisinsky

